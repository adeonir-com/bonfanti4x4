<?php

if ( ! defined('ABSPATH') ) {
    die() ;
}

LiteSpeed_Cache_ESI::get_instance()->load_esi_block() ;


