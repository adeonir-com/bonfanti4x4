<?php
if ( ! defined( 'WPINC' ) ) die ;
?>
<h3 class="litespeed-title"><?php echo __( 'Purge Network Settings', 'litespeed-cache' ) ; ?></h3>

<table><tbody>

	<?php require LSCWP_DIR . 'admin/tpl/setting/settings_inc.purge_on_upgrade.php' ; ?>

</tbody></table>
