<?php

namespace AC\Column;

interface AjaxValue {

	/**
	 * @param int $id
	 *
	 * @return void
	 */
	public function get_ajax_value( $id );

}