<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
?>
<div class='success updated'>
    <p><?php esc_html_e('Saved successfully', 'wpmf'); ?></p>
</div>
