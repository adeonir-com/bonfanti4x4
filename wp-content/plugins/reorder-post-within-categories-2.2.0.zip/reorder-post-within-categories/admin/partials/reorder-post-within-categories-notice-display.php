<?php
/*Display admin notice*/
?>
 <div class="updated re_order">
     <p><?= sprintf(__('First of all, you need to <a href="%s">save your settings for <em>ReOrder Posts in Categories</em></a>.', 'reorder-post-within-categories'), admin_url('options-general.php?page=reorder-posts-within-categories.php'));?></p>
 </div>
