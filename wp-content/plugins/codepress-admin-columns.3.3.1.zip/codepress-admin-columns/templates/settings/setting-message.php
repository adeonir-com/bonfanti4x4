<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<span class="message"><?php echo $this->message; ?></span>