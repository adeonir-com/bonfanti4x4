<?php

namespace AC;

interface Builder {

	public function build();

}